Thank you for downloading the Save and reading this txt

Author Steam : https://steamcommunity.com/id/496525622/

Enjoy